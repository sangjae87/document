package com.csj.webframework.cmmn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogTest {
    private static final Logger logger = LoggerFactory.getLogger(LogTest.class);

    public static void main(String[] args) {
//    	logger.info("정보 로그입니다.");
//        logger.debug("디버그 로그입니다.");
//        logger.warn("경고 로그입니다.");
//        logger.error("에러 로그입니다.");
        
        
        
        // ANSI 색상
        String ANSI_RESET = "\u001B[0m";
        String ANSI_GREEN = "\u001B[32m";
        String ANSI_PURPLE = "\u001B[35m";
        
        
        logger.debug(String.format("%s ANSI_PURPLE", ANSI_PURPLE));
        logger.debug(String.format("%s ANSI_GREEN", ANSI_GREEN));
        logger.debug(String.format("%s ANSI_RESET", ANSI_RESET));
        
        
    }
}