package com.csj.webframework.logging;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import com.p6spy.engine.spy.appender.MessageFormattingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RequestAwareLineFormat implements MessageFormattingStrategy {

    private static final Logger logger = LoggerFactory.getLogger(RequestAwareLineFormat.class);

    @Override
    public String formatMessage(int connectionId, String now, long elapsed, String category, String prepared, String sql, String url) {

    	// sql null 체크
        if (sql == null || sql.trim().isEmpty()) {
            return "";
        } else {
        	// SQL 예약어 색상 변경 (SELECT, FROM 등등)
            sql = highlightKeywords(sql);
        }

        // ANSI 색상
        String ANSI_RESET = "\u001B[0m";
        String ANSI_CYAN = "\u001B[36m";
        String ANSI_GREEN = "\u001B[32m";
        String ANSI_YELLOW = "\u001B[33m";
        String ANSI_PURPLE = "\u001B[35m";

        
//        %s[%sCurruntTime%s] %s%s %s(%s%dms%s)
//        \u001B[0m[\u001B[32mCurruntTime\u001B[0m] \u001B[32m2025-06-04 15:27:53 \u001B[0m(\u001B[32m21ms\u001B[0m)
//        [CurruntTime] 2025-06-04 15:27:53 (21ms)
        
        
        
        
        String uri = RequestLoggingFilter.currentRequest.get();
        if (uri == null) {
            uri = "(No URI)";
        }

        Timestamp timestamp = new Timestamp(Long.parseLong(now));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedTime = sdf.format(timestamp);

        String startStr = "\n --------------------------------------- START ----------------------------------------";
        String sqlFormat = "\n       " + sql + "\n"
                         + " ---------------------------------------- END -----------------------------------------\n";

        // 최종 출력 로그 스타일 지정
        String log = String.format(startStr + "\n%s[%sCurruntTime%s] %s%s %s(%s%dms%s)\n"
                        + "%s[%sURI%s] %s%s\n"
                        + "%s[%sSQL%s] %s",
                ANSI_RESET, ANSI_GREEN, ANSI_RESET, ANSI_GREEN, formattedTime, ANSI_RESET, ANSI_GREEN, elapsed, ANSI_RESET,
                ANSI_RESET, ANSI_CYAN, ANSI_RESET, ANSI_CYAN, uri,
                ANSI_RESET, ANSI_PURPLE, ANSI_RESET, sqlFormat
        );

        logger.info(log);
        return ""; // 콘솔에 출력만 하고 결과 문자열은 빈 값 반환 (stdout 중복 방지)
    }

    // SQL 예약어 색상 변경 ANSI_PURPLE 적용
    private static String highlightKeywords(String sql) {
        String ANSI_PURPLE = "\u001B[35m";
        String ANSI_RESET = "\u001B[0m";
        String[] keywords = { "SELECT", "FROM", "WHERE", "AND", "OR", "JOIN", "ON", "AS", "ORDER BY", "GROUP BY", "LIMIT", "WITH", "RECURSIVE", "UNION", "ALL" };
        for (String keyword : keywords) {
            sql = sql.replaceAll("(?i)\\b" + keyword + "\\b", ANSI_PURPLE + keyword.toUpperCase() + ANSI_RESET);
        }
        return sql;
    }
}
