package com.csj.webframework.application.board.web;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.csj.webframework.application.board.service.BoardService;
import com.csj.webframework.application.board.service.BoardVO;
import com.csj.webframework.application.main.web.MainController;


/**
 * @Class Name : BoardController.java
 * @Description : 게시판관련 컨트롤러
 * @Modification Information
 * @
 * @  수정일		수정자			수정내용
 * @ ---------	---------	-------------------------------
 * @ 2025.05.28	csj			최초생성
 *
 * @author csj
 * @since 2025. 05.28
 * @version 1.0
 * @see
 *
 */
@Controller
@RequestMapping(value = "/board")
public class BoardController {


	private static final Logger LOGGER = LoggerFactory.getLogger(BoardController.class);
	
	@Resource(name = "boardService")
	BoardService boardService;
	
	
	/**
	 * 게시글 목록을 조회한다. 
	 * @param 
	 * @param model
	 * @return 게시글 목록
	 * @exception Exception
	 */
	@RequestMapping(value = "/selectCommBoardList.do")
	public String selectBoardList(ModelMap model) throws Exception {

		
		BoardVO boardVO = new BoardVO();
		// board code 설정 (A: 공지사항 , B: 자유게시판)
		boardVO.setBoardCode("B");
		
		List<BoardVO> commBoardList = boardService.selectBoardList(boardVO);
		
		model.addAttribute("commBoardList", commBoardList);


		return "board/boardList";
	}
	
	
	
	/**
	 * 게시판으로 이동
	 * @param 
	 * @param model
	 * @return 공지사항 목록(공지사항)
	 * @exception Exception
	 */
	@RequestMapping(value = "/selectNoticeList.do")
	public String selectNoticeList(ModelMap model) throws Exception {


		BoardVO boardVO = new BoardVO();
		
		// board code 설정 ( A: 공지사항 , B: 자유게시판)
		boardVO.setBoardCode("A");
		
		List<BoardVO> noticeList = boardService.selectBoardList(boardVO);
		
		model.addAttribute("noticeList", noticeList);


		return "board/noticeList";
	}
	
	/**
	 * 게시판으로 상세 페이지 이동
	 * @param 
	 * @param model
	 * @return 게시글 조회
	 * @exception Exception
	 */
	@RequestMapping(value = "/viewNotice.do")
	public String selectNoticeView(ModelMap model, BoardVO boardVO ) throws Exception {

		LOGGER.debug("===================> {}", boardVO.getBoardId());
//		MainVO vo = new MainVO();
//		vo.setIdx(1);
//		List<MainVO> product = mainService.selectProductListByIdx(vo);
//		
//		List<MainVO> productList = mainService.selectProductList();
//		
//		model.addAttribute("productList", productList);
		
//		List<BoardVO> boardList = boardService.selectBoardList();
		
//		model.addAttribute("boardList", boardList);


		return "board/noticeView";
	}
}
