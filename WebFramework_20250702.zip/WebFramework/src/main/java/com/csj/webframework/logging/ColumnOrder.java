package com.csj.webframework.logging;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 * 필드 또는 getter 메서드에 지정하는 출력 순서용 어노테이션
 */
@Retention(RetentionPolicy.RUNTIME) // 런타임에도 접근 가능해야 함
@Target({ElementType.FIELD, ElementType.METHOD})         // 메서드(getter), field에 붙이기 위함
public @interface ColumnOrder {
    int value();
}
