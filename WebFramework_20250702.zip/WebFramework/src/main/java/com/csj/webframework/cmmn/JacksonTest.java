package com.csj.webframework.cmmn;

import java.util.HashMap;
import java.util.Map;

import com.csj.webframework.application.menu.service.MenuVO;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JacksonTest {

	public static void main(String[] args) throws Exception{
		ObjectMapper mapper = new ObjectMapper();

        // MenuVO 객체 생성
        MenuVO menu = new MenuVO();
        menu.setMenuId(1);
        menu.setParentId(0);
        menu.setMenuName("공지사항");
        menu.setMenuUrl("/board/selectNoticeList.do");
        menu.setLevel(1);
        menu.setFullPath("홈 > 게시판 > 공지사항");
        menu.setGroupCode("G014");

        // 객체 → JSON 문자열 (직렬화)
        String json = mapper.writeValueAsString(menu);
        System.out.println("직렬화 결과: " + json);

        // JSON 문자열 → 객체 (역직렬화)
        MenuVO parsed = mapper.readValue(json, MenuVO.class);
        System.out.println("역직렬화 결과: " + parsed);
	}
}
