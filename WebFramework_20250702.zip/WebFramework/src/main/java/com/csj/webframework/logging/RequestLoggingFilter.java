package com.csj.webframework.logging;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter;

public class RequestLoggingFilter extends OncePerRequestFilter {
    public static final ThreadLocal<String> currentRequest = new ThreadLocal<>();

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        currentRequest.set(request.getRequestURL().toString());
        try {
            filterChain.doFilter(request, response);
        } finally {
            currentRequest.remove();
        }
    }
}
