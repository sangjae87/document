package com.csj.webframework.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @Class Name : WebMvcConfig.java
 * @Description : Interceptor 등록처리
 * @Modification Information
 * @
 * @  수정일                  수정자                       수정내용
 * @ ---------  ---------   -------------------------------
 * @ 2025.06.30 csj         최초생성
 *
 * @author csj
 * @since 2025. 06.25
 * @version 1.0
 * @see
 *
 */

@Configuration
public class WebMvcConfig extends WebMvcConfigurerAdapter {

    @Autowired
    private MenuInterceptor menuInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(menuInterceptor)
                .addPathPatterns("/**");
    }
}