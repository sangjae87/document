package com.csj.webframework.cmmn;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @Class Name : CommonResponse.java
 * @Description : CommonResponse Class
 * @Modification Information
 *
 *
 *
 * @author csj
 * @since 2025.06.25
 * @version 1.0
 * @see
 *
 */
public class CommonResponse<T> {

    private final String status;
    private final String errorCode;
    private final String message;
    private final T data;

    private CommonResponse(String status, String errorCode, String message, T data) {
        this.status = status;
        this.errorCode = errorCode;
        this.message = message;
        this.data = data;
    }

    public static <T> CommonResponse<T> success(T data) {
        return new CommonResponse<>(MessageCode.SUCCESS.getMessage(), null, null, data);
    }

    public static <T> CommonResponse<T> success(T data, String message) {
        return new CommonResponse<>(MessageCode.SUCCESS.getMessage(), null, message, data);
    }

    public static <T> CommonResponse<T> error(String errorCode, String message) {
        return new CommonResponse<>(MessageCode.FAILURE.getMessage(), errorCode, message, null);
    }

    public String getStatus() {
        return status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }
}
