package com.csj.webframework.cmmn;

public class SnakeToCamelConverter {
	// 단일 문자열 변환
    public static String toCamelCase(String snakeCase) {
        if (snakeCase == null || snakeCase.isEmpty()) {
            return snakeCase;
        }

        StringBuilder result = new StringBuilder();
        boolean toUpper = false;

        for (int i = 0; i < snakeCase.length(); i++) {
            char ch = snakeCase.charAt(i);
            if (ch == '_') {
                toUpper = true;
            } else {
                result.append(toUpper ? Character.toUpperCase(ch) : Character.toLowerCase(ch));
                toUpper = false;
            }
        }

        return result.toString();
    }

    // 배열 처리 메서드
    public static String[] convertArrayToCamelCase(String[] snakeCases) {
        if (snakeCases == null) return null;

        String[] camelCases = new String[snakeCases.length];
        for (int i = 0; i < snakeCases.length; i++) {
            camelCases[i] = toCamelCase(snakeCases[i]);
        }
        return camelCases;
    }

    // 테스트용 main 메서드
    public static void main(String[] args) {
    	
    	
        String[] snakeArray = {"idx"
            	,"board_code"
            	,"board_title"
            	,"board_contents"
            	,"board_top_yn"
            	,"board_display_yn"
            	,"contents_display_yn"
            	,"file_code"
            	,"view_count"
            	,"reg_usr"
            	,"reg_date"
            	,"upd_usr"
            	,"upd_date"};
        String[] camelArray = convertArrayToCamelCase(snakeArray);

        for (String camel : camelArray) {
            System.out.println(camel);
        }
        // 출력:
        // userId
        // userName
        // createdAt
        // isActive
    }
}
