const noticeList = (function(){

	// 초기화 함수(화면 진입시 실행)
	function init(){
		console.log('공지사항')
		bindEvents();
		
	}
	
	// 이벤트 등록
	function bindEvents(){
		// click
		$(".btn").on("click",function(){
			// add더하는 기능
			add();			
		});
	}
	
	// 공지사항 목록 조회
	function selectNoticeList(){
		
		$.ajax({
			url: '/board/selectNoticeList.do',   // 서버 요청 URL
			type: 'POST',				   // POST 방식
			contentType: 'application/json', // 전송할 데이터 타입 (선택)
			data: JSON.stringify({
				title: '공지사항 제목',
				content: '내용입니다',
				writer: '홍길동'
			}),
			success: function(response) {
				console.log('등록 성공!', response);
				alert('게시글이 등록되었습니다.');
				
			},
			error: function(xhr, status, error) {
				console.error('등록 실패', error);
				alert('에러가 발생했습니다.');
			}
		});
		
		
	}
	
	function add(){
		let num = 0;
		num++;
		
		return num;
	}
	
	 
	
	return {
		init: init,
	}
	
})();

noticeList.init();



