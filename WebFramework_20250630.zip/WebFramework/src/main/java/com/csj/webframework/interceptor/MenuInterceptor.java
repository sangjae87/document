package com.csj.webframework.interceptor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.csj.webframework.application.menu.service.MenuService;
import com.csj.webframework.application.menu.service.MenuVO;

/**
 * @Class Name : MenuInterceptor.java
 * @Description : 메뉴 관련 Interceptor
 * @Modification Information
 * @
 * @  수정일				  수정자					   수정내용
 * @ ---------  ---------   -------------------------------
 * @ 2025.06.30 csj		 최초생성
 *
 * @author csj
 * @since 2025. 06.25
 * @version 1.0
 * @see
 *
 */

@Component
public class MenuInterceptor implements HandlerInterceptor {

	@Autowired
	private MenuService menuService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession();

		// 세션에 이미 있으면 재조회하지 않음
		@SuppressWarnings("unchecked")
		Map<MenuVO, List<MenuVO>> menuMap = (Map<MenuVO, List<MenuVO>>) session.getAttribute("menuMap");

		if (menuMap == null) {
			List<MenuVO> menuList = menuService.selectMenuList();

			
			// 순서를 기억하기위해 Linked를 사용
			menuMap = new LinkedHashMap<>();

			for (MenuVO menu : menuList) {
				if (menu.getLevel() == 2) {
					menu.setGroupCode("G" + String.format("%03d", menu.getMenuId()));

					List<MenuVO> subMenu = new ArrayList<>();
					for (MenuVO sub : menuList) {
						if (sub.getParentId() == menu.getMenuId()) {
							subMenu.add(sub);
						}
					}
					menuMap.put(menu, subMenu);
				}
			}

			session.setAttribute("menuMap", menuMap);
		}

		// JSTL에서도 바로 쓸 수 있도록 request에도 실어줌
		request.setAttribute("menuMap", menuMap);

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		
	}
}