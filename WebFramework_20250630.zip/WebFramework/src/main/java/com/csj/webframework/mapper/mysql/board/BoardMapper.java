package com.csj.webframework.mapper.mysql.board;

import java.util.List;

import com.csj.webframework.application.board.service.BoardVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * board에 관한 데이터처리 매퍼 클래스
 *
 * @author  csj
 * @since 2025.05.28
 * @version 1.0
 * @see <pre>
 *  == 개정이력(Modification Information) ==
 *
 *	수정일 					수정자				수정내용
 *  ----------------	------------	---------------------------
 *   2025.05.28			최상재		 		최초 생성
 *
 * 
 */
@Mapper("boardMapper")
public interface BoardMapper {

	List<BoardVO> selectBoardList(BoardVO boardVO);


}
