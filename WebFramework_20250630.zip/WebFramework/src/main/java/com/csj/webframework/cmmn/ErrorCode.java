package com.csj.webframework.cmmn;

/**
 * @Class Name : ErrorCode.java
 * @Description : ErrorCode Class
 * @Modification Information
 * 
 * 에러코드 정의
 * 
 * @author csj
 * @since 2025.06.25
 * @version 1.0
 * @see
 *
 */
public enum ErrorCode {
	
	// 200번대
	EMPTY_DATA("S200", "조회된 데이터가 없습니다."),							// 200 OK (정상이나 정보성 메시지)

	// 400번대: 클라이언트 요청 오류
	INVALID_INPUT_VALUE("E400", "입력값이 올바르지 않습니다."),					// 400 Bad Request
	MISSING_REQUIRED_PARAMETER("E400", "필수 요청 파라미터가 누락되었습니다."),		// 400 Bad Request
	UNAUTHORIZED("E401", "인증이 필요합니다."),								// 401 Unauthorized
	FORBIDDEN("E403", "요청에 대한 권한이 없습니다."),							// 403 Forbidden
	NOT_FOUND("E404", "요청한 리소스를 찾을 수 없습니다."),						// 404 Not Found
	METHOD_NOT_ALLOWED("E405", "허용되지 않은 HTTP 메서드입니다."),				// 405 Method Not Allowed
	DUPLICATE_REQUEST("E409", "중복된 요청입니다."),						// 409 Conflict
	UNSUPPORTED_MEDIA_TYPE("E415", "지원하지 않는 요청 형식입니다."),				// 415 Unsupported Media Type
	
	// 500번대: 서버 내부 오류
	INTERNAL_SERVER_ERROR("E500", "서버 내부 오류가 발생했습니다."),				// 500 Internal Server Error
	DATABASE_ERROR("E500", "데이터베이스 처리 중 오류가 발생했습니다."),				// 500 Internal Server Error
	NULL_POINTER_EXCEPTION("E500", "Null 값이 참조되었습니다."),				// 500 Internal Server Error
	IO_EXCEPTION("E500", "입출력 처리 중 오류가 발생했습니다."),					// 500 Internal Server Error
	EXTERNAL_API_ERROR("E502", "외부 시스템 연동 중 오류가 발생했습니다."),			// 502 Bad Gateway
	TIMEOUT_ERROR("E504", "처리 시간이 초과되었습니다."),						// 504 Gateway Timeout
	UNEXPECTED_EXCEPTION("E999", "예상하지 못한 예외가 발생했습니다.");			// 500 Internal Server Error
	
	
	private final String code;
	private final String message;
	
	ErrorCode(String code, String message) {
		this.code = code;
		this.message = message;
	}
	
	public String getCode() {
	return code;
	}
	
	public String getMessage() {
		return message;
	}
}