package com.csj.webframework.cmmn;

/**
 * @Class Name : MessageCode.java
 * @Description : MessageCode Class
 * @Modification Information
 * 
 * 메시지 코드 정의
 * 
 * @author csj
 * @since 2025.06.25
 * @version 1.0
 * @see
 *
 */
public enum MessageCode {

	SUCCESS("S001", "SUCCESS"), // 성공
	FAILURE("F001", "FAILURE"), // 실패
	EMPTY_DATA("S002", "조회된 데이터가 없습니다."); // 조회된 데이터가 없음.

	private final String code;
	private final String message;

	MessageCode(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}
}