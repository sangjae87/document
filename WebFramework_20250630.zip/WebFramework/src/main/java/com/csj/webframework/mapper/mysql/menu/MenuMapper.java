package com.csj.webframework.mapper.mysql.menu;

import java.util.List;

import com.csj.webframework.application.board.service.BoardVO;
import com.csj.webframework.application.menu.service.MenuVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * menu에 관한 데이터처리 매퍼 클래스
 *
 * @author  csj
 * @since 2025.06.25
 * @version 1.0
 * @see <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                                            수정자              수정내용
 *   ----------------    ------   ---------------------------
 *   2025.05.28          최상재               최초 생성
 *
 * 
 */
@Mapper("menuMapper")
public interface MenuMapper {

	List<BoardVO> selectBoardList(BoardVO boardVO);

	List<MenuVO> selectMenuList();


}
