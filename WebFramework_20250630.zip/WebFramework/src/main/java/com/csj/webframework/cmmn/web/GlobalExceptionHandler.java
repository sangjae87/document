package com.csj.webframework.cmmn.web;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.*;
import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;


import java.io.FileNotFoundException;
import java.io.IOException;

import com.csj.webframework.cmmn.CommonResponse;
import com.csj.webframework.cmmn.ErrorCode;

/**
 * @Class Name : GlobalExceptionHandler.java
 * @Description : GlobalExceptionHandler Class
 * @Modification Information

 * 
 * @author csj
 * @since 2025.06.25
 * @version 1.0
 * @see
 *
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private ResponseEntity<CommonResponse<Object>> buildResponse(ErrorCode errorCode, HttpStatus status, Exception ex) {
        LOGGER.error("[{}] {} : {} - {}", errorCode.getCode(), ex.getClass().getSimpleName() ,ex.getMessage(), errorCode.getMessage());
        
        // DEBUG 레벨에서만 출력
//        LOGGER.debug("StackTrace : " + ex);
        
        return ResponseEntity.ok(CommonResponse.error(errorCode.getCode(), errorCode.getMessage()));
    }

    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity<CommonResponse<Object>> handleNullPointer(NullPointerException ex) {
        return buildResponse(ErrorCode.NULL_POINTER_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<CommonResponse<Object>> handleIllegalArgument(IllegalArgumentException ex) {
        return buildResponse(ErrorCode.INVALID_INPUT_VALUE, HttpStatus.BAD_REQUEST, ex);
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<CommonResponse<Object>> handleIllegalState(IllegalStateException ex) {
        return buildResponse(ErrorCode.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<CommonResponse<Object>> handleDataAccess(DataAccessException ex) {
        return buildResponse(ErrorCode.DATABASE_ERROR, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }

    @ExceptionHandler(FileNotFoundException.class)
    public ResponseEntity<CommonResponse<Object>> handleFileNotFound(FileNotFoundException ex) {
        return buildResponse(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, ex);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<CommonResponse<Object>> handleIOException(IOException ex) {
        return buildResponse(ErrorCode.IO_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<CommonResponse<Object>> handleMethodNotAllowed(HttpRequestMethodNotSupportedException ex) {
        return buildResponse(ErrorCode.METHOD_NOT_ALLOWED, HttpStatus.METHOD_NOT_ALLOWED, ex);
    }

    @ExceptionHandler(BindException.class)
    public ResponseEntity<CommonResponse<Object>> handleBind(BindException ex) {
        return buildResponse(ErrorCode.INVALID_INPUT_VALUE, HttpStatus.BAD_REQUEST, ex);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<CommonResponse<Object>> handleValidation(MethodArgumentNotValidException ex) {
        return buildResponse(ErrorCode.INVALID_INPUT_VALUE, HttpStatus.BAD_REQUEST, ex);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<CommonResponse<Object>> handleGeneric(Exception ex) {
        return buildResponse(ErrorCode.UNEXPECTED_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }
}