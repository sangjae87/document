package com.csj.webframework.logging;

import org.apache.ibatis.executor.resultset.ResultSetHandler;
import org.apache.ibatis.plugin.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.sql.Statement;
import java.util.*;
import java.util.stream.Collectors;

@Intercepts({
    @Signature(type = ResultSetHandler.class, method = "handleResultSets", args = {Statement.class})
})
public class MyBatisResultLoggerAnsi implements Interceptor {

    private static final Logger logger = LoggerFactory.getLogger(MyBatisResultLoggerAnsi.class);

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_PURPLE = "\u001B[35m";  // 보라색
    private static final int MAX_ROWS = 100;

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object result = invocation.proceed();

        if (result instanceof List) {
            List<?> resultList = (List<?>) result;

            if (!resultList.isEmpty()) {
                Object first = resultList.get(0);
                Class<?> clazz = first.getClass();

                // 필드 정렬 (@ColumnOrder 기준)
                Field[] fields = clazz.getDeclaredFields();
                List<Field> orderedFields = Arrays.stream(fields)
                        .sorted(Comparator.comparingInt(f -> {
                            ColumnOrder order = f.getAnnotation(ColumnOrder.class);
                            return order != null ? order.value() : Integer.MAX_VALUE;
                        }))
                        .collect(Collectors.toList());

                // 최대 너비 계산 (헤더 vs 값 비교)
                Map<Field, Integer> columnWidths = new LinkedHashMap<>();
                for (Field field : orderedFields) {
                    field.setAccessible(true);
                    int max = field.getName().length();
                    for (Object row : resultList) {
                        Object val = field.get(row);
                        if (val != null) {
                            max = Math.max(max, val.toString().length());
                        }
                    }
                    columnWidths.put(field, max);
                }

                StringBuilder log = new StringBuilder();
                log.append(ANSI_PURPLE)
                   .append("\n [Query Result (" + resultList.size() + " rows)] \n")
                   .append(ANSI_RESET);

                // 헤더 출력
                for (Field field : orderedFields) {
                    int width = columnWidths.get(field);
                    log.append(String.format("| %-" + width + "s ", field.getName()));
                }
                log.append("|\n");

                // 구분선 출력
                for (Field field : orderedFields) {
                    int width = columnWidths.get(field);
                    log.append("+" + "-".repeat(width + 2));
                }
                log.append("+\n");

                // 데이터 출력
                int rowCount = 0;
                for (Object obj : resultList) {
                    if (rowCount++ >= MAX_ROWS) {
                        log.append(ANSI_YELLOW).append("⚠️ Too many rows, truncated at 100").append(ANSI_RESET).append("\n");
                        break;
                    }

                    for (Field field : orderedFields) {
                        int width = columnWidths.get(field);
                        Object val = field.get(obj);

                        String text;
                        String color = "";

                        if (val == null) {
                            text = "null";
                            color = ANSI_PURPLE;
                        } else {
                            text = val.toString();
                        }

                        log.append("| ").append(color).append(String.format("%-" + width + "s ", text)).append(ANSI_RESET);
                    }
                    log.append("|\n");
                }

                logger.info(log.toString());
            } else {
                logger.info("📭 Query returned no results.");
            }
        }

        return result;
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {}
}
