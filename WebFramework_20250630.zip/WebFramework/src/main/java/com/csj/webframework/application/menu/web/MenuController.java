package com.csj.webframework.application.menu.web;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csj.webframework.application.menu.service.MenuService;
import com.csj.webframework.application.menu.service.MenuVO;
import com.csj.webframework.cmmn.CommonResponse;
import com.csj.webframework.cmmn.ErrorCode;
import com.csj.webframework.cmmn.MessageCode;
import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

/**
 * @Class Name : MenuController.java
 * @Description : 메뉴 관련 클래스
 * @Modification Information
 * @
 * @  수정일                  수정자                       수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2025.06.25  csj         최초생성
 *
 * @author csj
 * @since 2025. 06.25
 * @version 1.0
 * @see
 *
 */
@RestController
@RequestMapping(value = "/menu")
public class MenuController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuController.class);
	
	@Resource(name = "menuService")
	MenuService menuService;
	
	
	
	/**
	 * 메뉴 목록을 조회한다. 
	 * @param 
	 * @param model
	 * @return 게시글 목록
	 * @exception Exception
	 */
	@RequestMapping(value = "/selectMenuList.do")
    public ResponseEntity<CommonResponse<List<MenuVO>>> selectMenuList3() {
		String responseMsg = "";
		
        List<MenuVO> menuList = menuService.selectMenuList();

//        menuList = null;
        if (menuList == null || menuList.isEmpty()) {
        	responseMsg = MessageCode.EMPTY_DATA.getMessage(); 
        	menuList = Collections.emptyList();
        }

        return ResponseEntity.ok(CommonResponse.success(menuList, responseMsg));
    }
	
	
	/**
	 * 메뉴 목록을 조회한다.
	 * Map사용방식
	 *  
	 * @param 
	 * @param model
	 * @return 게시글 목록
	 * @exception Exception
	 */
	@RequestMapping(value = "/selectMenuList2.do")
	public Map<String, Object> selectMenuList2() {
		
		
		Map<String, Object> result = new HashMap<>();

	    try {
	        List<MenuVO> menuList = menuService.selectMenuList();

	        if (menuList == null || menuList.isEmpty()) {
	            ErrorCode error = ErrorCode.EMPTY_DATA;

	            result.put("success", false);
	            result.put("errorCode", error.getCode());
	            result.put("message", error.getMessage());
	            result.put("menuList", Collections.emptyList());
	        } else {
	            result.put("success", true);
	            result.put("menuList", menuList);
	        }

	    } catch (Exception e) {
	        ErrorCode error = ErrorCode.INTERNAL_SERVER_ERROR;
	        result.put("success", false);
	        result.put("errorCode", error.getCode());
	        result.put("message", error.getMessage());
	        result.put("menuList", Collections.emptyList());
	    }

	    return result;
	}
	
}
