const menuModule = (function(){

	// 초기화 함수(화면 진입시 실행)
	function init(){
		console.log('menu.js init')
		bindEvents();
		selectMenuList();
		
	}
	
	// 이벤트 등록
	function bindEvents(){
		// click
		$(".btn").on("click",function(){
		});
	}
	
	// 메뉴 목록 조회
	function selectMenuList(){
		
		$.ajax({
			url: '/menu/selectMenuList.do',   // 서버 요청 URL
			type: 'get',				   
//			dataType: 'json',
			success: function(response) {
				console.log('메뉴 조회 성공!', response);
				
				
				if(response.status === "SUCCESS"){
					
					let menuList = response.data;
					
					let idMap = new Map();
				    let groupMap = new Map();

				    menuList.forEach(function(item) {
				        idMap.set(item.menuId, Object.assign({}, item, { children: [] }));

				        if (!groupMap.has(item.groupCode)) {
				            groupMap.set(item.groupCode, []);
				        }
				        groupMap.get(item.groupCode).push(item);
				    });

				    idMap.forEach(function(menu) {
				        if (menu.parentId !== 0) {
				            let parent = idMap.get(menu.parentId);
				            if (parent) {
				                parent.children.push(menu);
				            }
				        }
				    });

				    let html = '<ul class="gnb">\n';

				    let index = 1;

				    groupMap.forEach(function(items, groupCode) {
				        let mainMenu = items.find(function(item) {
				            return item.level === 2;
				        });

				        if (mainMenu && mainMenu.parentId !== 0) {
				            let mainMenuObj = idMap.get(mainMenu.menuId);

				            // 첫 번째 서브메뉴가 있다면, 그 URL로 메인메뉴 URL 덮어쓰기
				            if (mainMenuObj.children.length > 0) {
				                mainMenuObj.menuUrl = mainMenuObj.children[0].menuUrl;
				            }

				            html += '    <li class="menu_li menu_li' + (index < 10 ? '0' + index : index) + '">\n';
				            html += '        <a href="' + mainMenuObj.menuUrl + '" class="menu_name">' + mainMenuObj.menuName + '</a>\n';

				            if (mainMenuObj.children.length > 0) {
				                html += '        <ul class="sub">\n';

				                mainMenuObj.children.forEach(function(sub) {
				                    html += '            <li class="sub_list">\n';
				                    html += '                <a href="' + sub.menuUrl + '" class="sub_list_name">' + sub.menuName + '</a>\n';
				                    html += '            </li>\n';
				                });

				                html += '        </ul>\n';
				            }

				            html += '    </li>\n';
				            index++;
				        }
				    });

				    html += '</ul>';
				    
				    $(".menu_layOut").html(html);
				}
				
			},
			error: function(xhr) {
				console.log('조회 실패');
			}
		});
		
	}
	
	// 메뉴 생성
	function createMenuList(menuList){
		
		console.log("메뉴 생성");
		
		
	}
	
	return {
		init: init,
	}
	
})();

menuModule.init();



