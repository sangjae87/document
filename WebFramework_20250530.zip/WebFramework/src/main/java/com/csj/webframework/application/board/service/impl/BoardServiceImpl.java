package com.csj.webframework.application.board.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csj.webframework.application.board.service.BoardService;
import com.csj.webframework.application.board.service.BoardVO;
import com.csj.webframework.mapper.mysql.board.BoardMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : BoardServiceImpl.java
 * @Description : 게시판관련 비즈니스 로직 작성
 * @Modification Information
 * @
 * @  수정일		수정자			수정내용
 * @ ---------	---------	-------------------------------
 * @ 2025.05.28	csj			최초생성
 *
 * @author csj
 * @since 2025. 05.28
 * @version 1.0
 * @see
 *
 */

@Service("boardService")
@Transactional(transactionManager = "mysqlTransactionManager")
public class BoardServiceImpl extends EgovAbstractServiceImpl implements BoardService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BoardServiceImpl.class);

	@Resource(name = "boardMapper")
	private BoardMapper boardMapper;

	@Override
	public List<BoardVO> selectBoardList() {
		return boardMapper.selectBoardList();
	}


}
