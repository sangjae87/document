package com.csj.webframework.application.board.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.csj.webframework.application.board.service.BoardService;
import com.csj.webframework.application.board.service.BoardVO;

/**
 * @Class Name : BoardController.java
 * @Description : 게시판관련 컨트롤러
 * @Modification Information
 * @
 * @  수정일		수정자			수정내용
 * @ ---------	---------	-------------------------------
 * @ 2025.05.28	csj			최초생성
 *
 * @author csj
 * @since 2025. 05.28
 * @version 1.0
 * @see
 *
 */
@Controller
public class BoardController {


	@Resource(name = "boardService")
	BoardService boardService;
	
	
	/**
	 * 게시글 조회한다. 
	 * @param 
	 * @param model
	 * @return 게시글 목록
	 * @exception Exception
	 */
	@RequestMapping(value = "/boardList.do")
	public String selectSampleList(ModelMap model) throws Exception {

		
		List<BoardVO> boardList = boardService.selectBoardList();
		
		model.addAttribute("boardList", boardList);


		return "board/boardList";
	}
}
