package com.csj.webframework.application.board.service;

import com.csj.webframework.logging.ColumnOrder;

/**
 * @Class Name : BoardVO.java
 * @Description : 게시판관련 VO
 * @Modification Information
 * @
 * @  수정일		수정자			수정내용
 * @ ---------	---------	-------------------------------
 * @ 2025.05.28	csj			최초생성
 *
 * @author csj
 * @since 2025. 05.28
 * @version 1.0
 * @see
 *
 */
public class BoardVO  {
	
	@ColumnOrder(1)
	private String idx;
	
	@ColumnOrder(2)
	private String boardCode;
	
	@ColumnOrder(12)
	private String boardTitle;
	
	@ColumnOrder(13)
	private String boardContents;
	
	@ColumnOrder(7)
	private String boardTopYn;
	
	@ColumnOrder(8)
	private String boardDisplayYn;
	
	@ColumnOrder(9)
	private String contentsDisplayYn;
	
	@ColumnOrder(10)
	private String fileCode;
	
	@ColumnOrder(11)
	private String viewCount;
	
	@ColumnOrder(3)
	private String regUsr;
	
	@ColumnOrder(4)
	private String regDate;
	
	@ColumnOrder(5)
	private String updUsr;
	
	@ColumnOrder(6)
	private String updDate;
	/**
	 * @return the idx
	 */
	public String getIdx() {
		return idx;
	}
	/**
	 * @param idx the idx to set
	 */
	public void setIdx(String idx) {
		this.idx = idx;
	}
	/**
	 * @return the boardCode
	 */
	public String getBoardCode() {
		return boardCode;
	}
	/**
	 * @param boardCode the boardCode to set
	 */
	public void setBoardCode(String boardCode) {
		this.boardCode = boardCode;
	}
	/**
	 * @return the boardTitle
	 */
	public String getBoardTitle() {
		return boardTitle;
	}
	/**
	 * @param boardTitle the boardTitle to set
	 */
	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}
	/**
	 * @return the boardContents
	 */
	public String getBoardContents() {
		return boardContents;
	}
	/**
	 * @param boardContents the boardContents to set
	 */
	public void setBoardContents(String boardContents) {
		this.boardContents = boardContents;
	}
	/**
	 * @return the boardTopYn
	 */
	public String getBoardTopYn() {
		return boardTopYn;
	}
	/**
	 * @param boardTopYn the boardTopYn to set
	 */
	public void setBoardTopYn(String boardTopYn) {
		this.boardTopYn = boardTopYn;
	}
	/**
	 * @return the boardDisplayYn
	 */
	public String getBoardDisplayYn() {
		return boardDisplayYn;
	}
	/**
	 * @param boardDisplayYn the boardDisplayYn to set
	 */
	public void setBoardDisplayYn(String boardDisplayYn) {
		this.boardDisplayYn = boardDisplayYn;
	}
	/**
	 * @return the contentsDisplayYn
	 */
	public String getContentsDisplayYn() {
		return contentsDisplayYn;
	}
	/**
	 * @param contentsDisplayYn the contentsDisplayYn to set
	 */
	public void setContentsDisplayYn(String contentsDisplayYn) {
		this.contentsDisplayYn = contentsDisplayYn;
	}
	/**
	 * @return the fileCode
	 */
	public String getFileCode() {
		return fileCode;
	}
	/**
	 * @param fileCode the fileCode to set
	 */
	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}
	/**
	 * @return the viewCount
	 */
	public String getViewCount() {
		return viewCount;
	}
	/**
	 * @param viewCount the viewCount to set
	 */
	public void setViewCount(String viewCount) {
		this.viewCount = viewCount;
	}
	/**
	 * @return the regUsr
	 */
	public String getRegUsr() {
		return regUsr;
	}
	/**
	 * @param regUsr the regUsr to set
	 */
	public void setRegUsr(String regUsr) {
		this.regUsr = regUsr;
	}
	/**
	 * @return the regDate
	 */
	public String getRegDate() {
		return regDate;
	}
	/**
	 * @param regDate the regDate to set
	 */
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	/**
	 * @return the updUsr
	 */
	public String getUpdUsr() {
		return updUsr;
	}
	/**
	 * @param updUsr the updUsr to set
	 */
	public void setUpdUsr(String updUsr) {
		this.updUsr = updUsr;
	}
	/**
	 * @return the updDate
	 */
	public String getUpdDate() {
		return updDate;
	}
	/**
	 * @param updDate the updDate to set
	 */
	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}
	  
	  
	  
	
	
}
