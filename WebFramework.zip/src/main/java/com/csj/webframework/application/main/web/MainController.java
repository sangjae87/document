package com.csj.webframework.application.main.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.csj.webframework.application.main.service.MainService;
import com.csj.webframework.application.main.service.MainVO;

/**
 * @Class Name : MainController.java
 * @Description : 메인페이지 관련 클래스
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2025.04.16           최초생성
 *
 * @author csj
 * @since 2025. 04.16
 * @version 1.0
 * @see
 *
 */
@Controller
public class MainController {


	@Resource(name = "mainService")
	MainService mainService;
	
	/**
	 * 메인페이지 호출
	 * @param 
	 * @param 
	 * @return main.jsp
	 * @exception 
	 */
	@RequestMapping(value = "/test.do")
	public String test(ModelMap model) throws Exception {
		return "test";
	}
	
	/**
	 * 메인페이지 호출
	 * @param 
	 * @param 
	 * @return main.jsp
	 * @exception 
	 */
	@RequestMapping(value = "/main.do")
	public String main(ModelMap model) throws Exception {
		return "main/main";
	}
	
	/**
	 * 메인페이지 호출
	 * @param 
	 * @param 
	 * @return main.jsp
	 * @exception 
	 */
	@RequestMapping(value = "/mainPopup.do")
	public String mainPopup(ModelMap model) throws Exception {
		return "main/mainPopup.popup";
	}
	
	/**
	 * 메인페이지 호출
	 * @param 
	 * @param 
	 * @return main.jsp
	 * @exception 
	 */
	@RequestMapping(value = "/testPopup.do")
	public String testPopup(ModelMap model) throws Exception {
		return "testPopup.popup";
	}
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 SampleDefaultVO
	 * @param model
	 * @return "egovSampleList"
	 * @exception Exception
	 */
	@RequestMapping(value = "/productList.do")
	public String selectSampleList(ModelMap model) throws Exception {


		List<MainVO> productList = mainService.selectProductList();
		System.out.println("================> " + productList);
		model.addAttribute("productList", productList);


		return "main/product";
	}
}
