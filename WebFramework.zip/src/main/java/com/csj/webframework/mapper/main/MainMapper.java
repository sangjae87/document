package com.csj.webframework.mapper.main;

import java.util.List;

import com.csj.webframework.application.main.service.MainVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * main에 관한 데이터처리 매퍼 클래스
 *
 * @author  csj
 * @since 2025.05.13
 * @version 1.0
 * @see <pre>
 *  == 개정이력(Modification Information) ==
 *
 *	수정일 					수정자				수정내용
 *  ----------------	------------	---------------------------
 *   2025.05.13			최상재		 		최초 생성
 *
 * 
 */
@Mapper("mainMapper")
public interface MainMapper {

	/**
	 * 테스트 데이터 조회.
	 * @param 
	 * @return 조회 결과
	 * @exception Exception
	 */
	List<MainVO> selectProductList();

}
