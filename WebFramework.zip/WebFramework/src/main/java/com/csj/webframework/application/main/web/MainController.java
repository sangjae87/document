package com.csj.webframework.application.main.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Class Name : MainController.java
 * @Description : 메인페이지 관련 클래스
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2025.04.16           최초생성
 *
 * @author csj
 * @since 2025. 04.16
 * @version 1.0
 * @see
 *
 */
@Controller
public class MainController {


	/**
	 * 메인페이지 호출
	 * @param 
	 * @param 
	 * @return main.jsp
	 * @exception 
	 */
	@RequestMapping(value = "/main.do")
	public String main(ModelMap model) throws Exception {
		return "main/main";
	}
}
