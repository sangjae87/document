
$(function(){
    // TAB 버튼 클릭시
    $('.tab_front button').click(function(){
        $('.tab_front button').removeClass('tab_btn_active');
        $(this).addClass('tab_btn_active');
    });

    
});