
$(function(){
    // 상단 메뉴 클릭시
    $(".gnb .menu_li").mouseenter(function () {
        $(this).find(".sub").stop().slideDown(200);
    });
    $(".gnb .menu_li").mouseleave(function () {
        $(this).find(".sub").stop().slideUp(200);
    });

    // 메인슬라이드
    mainSlider = 0
    slide1()
    

    // 슬라이드 순환
    setInterval(function() {
        mainSlider++;
        mainSlider = mainSlider % 3; 
        slide1();
    }, 5000);

    function slide1() {
        console.log("슬라이드:" + mainSlider);
        $(".banner_layOut .banner_img_list").eq(mainSlider).stop().fadeIn();
        $(".banner_layOut .banner_img_list").not($(".banner_layOut .banner_img_list").eq(mainSlider)).stop().fadeOut();
    };

    $(".pageNav .prev_btn").click(function () {
        mainSlider--;
        mainSlider = mainSlider % 3;
        slide1();
    });

    $(".pageNav .Next_btn").click(function () {
        mainSlider++;
        mainSlider = mainSlider % 3;
        slide1();
    });

    // 모바일메뉴 관련
    $('.mb_gnb .menu_name').click(function () {
        const $currentSub = $(this).next('.sub');
        if (!$currentSub.is(':visible')) {
            $('.sub').slideUp();
            $currentSub.stop(true, true).slideDown(); 
        } else {
            $currentSub.slideUp();
        };
    });

    $('.mobile_menu .mobile_menu_btn').click(function(){
        $('.mb_gnb').show();
    });
    $('.mb_gnb .mb_close button').click(function(){
        $('.mb_gnb').hide();
    });

});