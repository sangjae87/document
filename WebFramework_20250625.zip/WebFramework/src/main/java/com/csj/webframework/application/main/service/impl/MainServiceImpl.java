package com.csj.webframework.application.main.service.impl;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csj.webframework.application.main.service.MainService;
import com.csj.webframework.application.main.service.MainVO;
import com.csj.webframework.mapper.postgres.main.MainMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : MainController.java
 * @Description : 메인페이지 관련 클래스
 * @Modification Information
 * @
 * @  수정일 		수정자			수정내용
 * @ ---------	---------	-------------------------------
 * @ 2025.04.16	csj			최초생성
 *
 * @author csj
 * @since 2025. 04.16
 * @version 1.0
 * @see
 *
 */

@Service("mainService")
@Transactional(transactionManager = "mysqlTransactionManager")
public class MainServiceImpl extends EgovAbstractServiceImpl implements MainService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MainServiceImpl.class);

	@Resource(name = "mainMapper")
	private MainMapper mainMapper;

	@Override
	public List<MainVO> selectProductList() {
		return mainMapper.selectProductList();
	}

	@Override
	public List<MainVO> selectProductListByIdx(MainVO vo) {
		return mainMapper.selectProductListByIdx(vo);
	}
	
}
