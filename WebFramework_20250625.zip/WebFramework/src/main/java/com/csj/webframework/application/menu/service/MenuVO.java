package com.csj.webframework.application.menu.service;

/**
 * @Class Name : SampleVO.java
 * @Description : SampleVO Class
 * @Modification Information
 * @
 * @  수정일                  수정자                       수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2025.06.25  csj         최초생성
 *
 * @author csj
 * @since 2025. 06.25
 * @version 1.0
 * @see
 *
 */
public class MenuVO  {
	

}
