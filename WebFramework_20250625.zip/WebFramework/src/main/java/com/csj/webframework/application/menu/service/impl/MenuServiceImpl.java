package com.csj.webframework.application.menu.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csj.webframework.application.menu.service.MenuService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : MenuController.java
 * @Description : 메뉴 관련 클래스
 * @Modification Information
 * @
 * @  수정일                  수정자                       수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2025.06.25  csj         최초생성
 *
 * @author csj
 * @since 2025. 06.25
 * @version 1.0
 * @see
 *
 */
@Service("menuService")
@Transactional(transactionManager = "mysqlTransactionManager")
public class MenuServiceImpl extends EgovAbstractServiceImpl implements MenuService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuServiceImpl.class);

	
}
