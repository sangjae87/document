package com.csj.webframework.application.main.service;

import java.util.List;

/**
 * @Class Name : MainController.java
 * @Description : 메인페이지 관련 클래스
 * @Modification Information
 * @
 * @  수정일 		수정자			수정내용
 * @ ---------	---------	-------------------------------
 * @ 2025.04.16	csj			최초생성
 *
 * @author csj
 * @since 2025. 04.16
 * @version 1.0
 * @see
 *
 */
public interface MainService {

	List<MainVO> selectProductList();

	List<MainVO> selectProductListByIdx(MainVO vo);


}
